<?php
            require 'header.php';
           ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shipping Policey</title>
</head>
<body>
        <div  align="center">
            <img src="assets/img/shipping1.png" ><img src="assets/img/shipping-policy.png" >
        </div>
           <br><br>
    <div class="container-fluid bd-container" align="justify">
    <h1>Shipping Policy</h1><br>
    <p>Most people think of a shipping policy as legal protection, but we actually view it as a sales tool. <br>
     A clear and enticing shipping policy sets expectations for potential customers and builds trust leading to higher conversion rates. <br>
    This document sets out the shipping policy that applies to customers that make a purchase at [Mobile Space]. <br>
    If you have any questions, please contact our customer service team on [+923136033913] .</p><br><br>
    <h3>Shipping Options & Delivery Costs</h3><br>
    <p>We offer the following shipping option- <br>
[ RS: 500/- Normal (2-4 Business days)  ---- ]</p><br><br>
<h3>Order Processing Time</h3><br>
<p>All orders placed before 2 PM Monday to Friday are processed and dispatched the same day, all orders placed after will be dispatched the next day. <br>
 All orders placed during the weekend or on a public holiday will be sent from our warehouse on Monday or on the next business day.</p><br><br>
 <h3>Delivery Address & P.O. Boxes</h3><br>
 <p>Please note that we are unable to modify the delivery address once you have placed your order. <br>!!! We are sorry but we do not ship to P.O. boxes.</p><br><br>
 <h3>Tracking Your Order</h3><br>
 <p>Once your order has been dispatched, we will send you a confirmation E-Mail and SMS with tracking information. <br> You will be able to track your package directly on the carrier's website.</p><br><br>
 </div>
 <?php include("footer.php") ; ?>
</body>
<style>
    body {
  font-size: 100%;
  font color: black;
}

h1 {
  font-size: 2.5em;
}

h2 {
  font-size: 2em;
}

p {
  font-size: 1.5em;
}
</style>
</html>