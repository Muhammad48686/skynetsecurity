<?php
    require 'connection.php';
    session_start();
    $order_id=$_GET['id'];
    $quantity=$_POST['quantity'];
    $query="SELECT `item_price` FROM `orders` where order_id='$order_id'  ";
    $queryfire=mysqli_query($con,$query);
    $product =mysqli_fetch_array($queryfire);
    $price=$product['item_price'];
    $total_price=$price*$quantity;
    $update_query="update orders set quantity=$quantity,total_price=$total_price where order_id=$order_id ";
    $update_query_result=mysqli_query($con,$update_query) or die(mysqli_error($con));
    header('location: cart.php');
?>