<?php
require 'connection.php';
require 'check_if_added.php';
?>
<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!--========== BOX ICONS ==========-->
        <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>

        <!--========== CSS ==========-->
        <link rel="stylesheet" href="assets/css/styles.css">
        

        <title>E-MobiTech | Homepage</title>

    </head>
    <body>
    <div>
    <?php
    require 'header.php';
    ?>
    </div>
    <main class="l-main">
           <!--========== HOME ==========-->
            <section class="home" id="home">
                <div class="home__container bd-container bd-grid">
                    <div class="home__img">
                    <?php include("slider.php") ; ?>
                    </div>

                    <div class="home__data">
                        <h1 class="home__title">Welcome to E-MobiTech Online Store</h1>
                       <h5 class="home__description">Buy the latest Mobile Smart-Phones and high quality Mobile Accessories of different Brands  that are available in our Store.</h5>
                        <a href="products.php" class="button">Explore Products</a>
                    </div>
                </div>
            </section>
            <!--========== SHARE ==========-->
            <section class="share section bd-container" id="share">
                <div class="share__container bd-grid">
                    <div class="share__data">
                        <h2 class="section-title-center">Buy Mobiles with more Discounts and Share happiness </h2>
                        <h5 class="share__description"> Upto 10% OFF-- <br> Special Discount on Flagship, Mid range and Entry-Level Smartphones and Mobile Accessories.</h5>
                        <a href="products.php?p=discounts" class="button">Explore Offers</a>
                    </div>
                    <div class="share__img">
                        <img src="assets/img/4.jpg">
                    </div>
                </div>
            </section>

            <!--========== brands ==========-->
            <section class="brands section bd-container" id="brands">
                <h2 class="section-title">Available Brands</h2>
                <div class="brands__container bd-grid">
                    <div class="brands__data">
                        <a href="products.php?p=apple" class="button button-link"><img src="assets/img/al.png" alt="" class="brands__img"> <br><br> Go Shopping</a>
                    </div>
                    <div class="brands__data">
                        <a href="products.php?p=samsung" class="button button-link"><img src="assets/img/sl.png" alt="" class="brands__img"> <br><br> Go Shopping</a>
                    </div>
                    <div class="brands__data">
                        <a href="products.php?p=vivo" class="button button-link"><img src="assets/img/vl.png" alt="" class="brands__img"> <br><br> Go Shopping</a>
                    </div>
                    <div class="brands__data">
                        <a href="products.php?p=oppo" class="button button-link"><img src="assets/img/ol.png" alt="" class="brands__img"> <br> Go Shopping</a>
                    </div>
                    <div class="brands__data">
                        <a href="products.php?p=xiaomi" class="button button-link"><img src="assets/img/xl.png" alt="" class="brands__img"><br> <br> Go Shopping</a>
                    </div>
                    <div class="brands__data">
                        <a href="products.php?p=nokia" class="button button-link"><img src="assets/img/nl.png" alt="" class="brands__img"><br> <br> Go Shopping</a>
                    </div>
                    <div class="brands__data">
                        <a href="products.php?p=anker" class="button button-link"><img src="assets/img/anker-logo.png" alt="" class="brands__img"><br><br><br><br><br> Go Shopping</a>
                    </div>
                    <div class="brands__data">
                        <a href="products.php?p=gionee" class="button button-link"><img src="assets/img/gl.png" alt="" class="brands__img"><br><br><br><br><br> Go Shopping</a>
                    </div>
                </div>
            </section>

            <!--========== ACCESSORIES ==========-->
            <section class="accessory section bd-container" id="accessory">
                <h2 class="section-title">Best Quality <br> Accessories</h2>
                 <?php
                     $query="SELECT * FROM `items` where type='accessory' order by price asc limit 3";
                    $queryfire=mysqli_query($con,$query);
                    $num=mysqli_num_rows($queryfire);
                 ?>
                <div class="accessory__container bd-grid">
                    <?php
                    if($num > 0){
                      while($product =mysqli_fetch_array($queryfire)){ 
                     ?>
                            <div class="accessory__content">
                            <img src="assets/img/<?php echo $product['image'] ;?>" alt="" class="accessory__img">
                            <h2 class="accessory__title"><?php echo $product['title']; ?> </h2>
                            <h6><s> &#8360; <?php echo  $product['price']; ?></s></h6>
                            <h6 class="accessory__preci">&#8360; <?php echo  $product['new_price']; ?><span>(<?php echo  $product['discount']; ?> % OFF)</span></h6>
                            <?php if(!isset($_SESSION['email'])){  ?>
                                        <p><a href="login.php"   class="accessory__button btn-danger">Buy Now</a></p>
                                        <?php
                                        }
                                        else{
                                            if(check_if_added_to_cart($product['id'])){
                                                echo '<a href="cart.php"  class="accessory__button btn-success">Added to cart</a>';
                                            }else{
                                                ?>
                                                <a href="cart_add.php? id=<?php echo $product['id'];?>" name="add" value="add" class="accessory__button   btn-dark">Add to cart</a>
                                                <?php
                                            }
                                        }
                                        ?>
                            </div>
               
                            <?php
                        }
                    }
                    ?>
                </div>
            </section>
            <div class="container" align="right">
            <a href="products.php?p=accessories" class="btn btn-outline-danger">Explore More</a>
            </div>
            <?php include("footer.php") ; ?>
    </body>
</html>