<!-- Footer Section Starts -->
<div class="footer">
            <div class="wrapper">
            <br><br>
            <center> &copy <?php echo date("Y"); ?> Mobile-Space. All Rights Reserved. Developed by : Syed M. Mubashir Ahmad</center>
            
            </div>
        </div>
        <!-- Footer Section Ends -->

    </body>
</html>