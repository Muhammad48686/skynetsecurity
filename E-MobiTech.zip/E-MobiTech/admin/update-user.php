<?php include('partials/menu.php'); ?>

<div class="main-content">
    <div class="wrapper">
        <h1>Update User</h1>

        <br><br>

        <?php 
            //1. Get the ID of Selected User
            $id=$_GET['id'];

            //2. Create SQL Query to Get the Details
            $sql="SELECT * FROM Users WHERE id=$id";

            //Execute the Query
            $res=mysqli_query($conn, $sql);

            //Check whether the query is executed or not
            if($res==true)
            {
                // Check whether the data is available or not
                $count = mysqli_num_rows($res);
                //Check whether we have User data or not
                if($count==1)
                {
                    // Get the Details
                    //echo "User Available";
                    $row=mysqli_fetch_assoc($res);

                    $full_name = $row['name'];
                    $email = $row['email'];
                    $contact = $row['contact'];
                    $debitcard = $row['debitcard'];
                    $address = $row['address'];
                    $city = $row['city'];

                }
                else
                {
                    //Redirect to Manage User PAge
                    header('location:'.SITEURL.'admin/manage-user.php');
                }
            }
        
        ?>


        <form action="" method="POST">

            <table class="tbl-30">
                <tr>
                    <td>Full Name: </td>
                    <td>
                        <input type="text" name="full_name" value="<?php echo $full_name; ?>">
                    </td>
                </tr>


                <tr>
                    <td>E-mail: </td>
                    <td>
                        <input type="text" name="email" value="<?php echo $email; ?>">
                    </td>
                </tr>
                <tr>
                    <td>Contact: (11-digit) </td>
                    <td>
                        <input type="tel" name="contact" value="<?php echo $contact; ?>">
                    </td>
                </tr>   <tr>
                    <td>Address: </td>
                    <td>
                        <input type="textarea" name="address" value="<?php echo $address; ?>">
                    </td>
                </tr>
                <tr>
                    <td>City: </td>
                    <td>
                        <input type="text" name="city" value="<?php echo $city; ?>">
                    </td>
                </tr>
                <tr>
                    <td>Debitcard#: (16-Digit) </td>
                    <td>
                        <input type="tel" name="debitcard" value="<?php echo $debitcard; ?>">
                    </td>
                </tr>
                

                <tr>
                    <td colspan="2">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <input type="submit" name="submit" value="Update user" class="btn-secondary">
                    </td>
                </tr>

            </table>

        </form>
    </div>
</div>

<?php 

    //Check whether the Submit Button is Clicked or not
    if(isset($_POST['submit']))
    {
        //echo "Button CLicked";
        //Get all the values from form to update
        $id = $_POST['id'];
        $full_name = $_POST['full_name'];
        $email = $_POST['email'];
        $contact = $_POST['contact'];
        $address = $_POST['address'];
        $city = $_POST['city'];
        $debitcard = $_POST['debitcard'];

        //Create a SQL Query to Update user
        $sql = "UPDATE users SET
        name = '$full_name',
        email = '$email',
        contact = '$contact',
        address = '$address',
        city = '$city',
        debitcard = '$debitcard'
        WHERE id='$id'
        ";

        //Execute the Query
        $res = mysqli_query($conn, $sql);

        //Check whether the query executed successfully or not
        if($res==true)
        {
            //Query Executed and user Updated
            $_SESSION['update'] = "<div class='success'>User Updated Successfully.</div>";
            //Redirect to Manage user Page
            header('location:'.SITEURL.'admin/manage-user.php');
        }
        else
        {
            //Failed to Update user
            $_SESSION['update'] = "<div class='error'>Failed to Update user.</div>";
            //Redirect to Manage user Page
            header('location:'.SITEURL.'admin/manage-user.php');
        }
    }

?>


<?php include('partials/footer.php'); ?>