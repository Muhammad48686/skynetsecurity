<?php include('partials/menu.php'); ?>


        <!-- Main Content Section Starts -->
        <div class="main-content">
            <div class="wrapper">
                <h1>Manage Users/ Customers</h1>


                <br><br><br>
                <?php
                   if(isset($_SESSION['delete']))
                   {
                       echo $_SESSION['delete'];
                       unset($_SESSION['delete']);
                   }
                   
                   if(isset($_SESSION['update']))
                   {
                       echo $_SESSION['update'];
                       unset($_SESSION['update']);
                   }
                   ?>
                <br /><br /><br />

                <table class="tbl-full">
                    <tr>
                        <th width="5%">S.N.</th>
                        <th width="15%">Full Name</th>
                        <th width="20%">Email</th>
                        <th width="12%">Contact</th>
                        <th width="20%">Address</th>
                        <th width="15%">Debit card#</th>
                        <th width="13%">Actions</th>
                    </tr>

                    
                    <?php 
                        //Query to Get all Users
                        $sql = "SELECT * FROM Users";
                        //Execute the Query
                        $res = mysqli_query($conn, $sql);

                        //CHeck whether the Query is Executed of Not
                        if($res==TRUE)
                        {
                            // Count Rows to CHeck whether we have data in database or not
                            $count = mysqli_num_rows($res); // Function to get all the rows in database

                            $sn=1; //Create a Variable and Assign the value

                            //CHeck the num of rows
                            if($count>0)
                            {
                                //WE HAve data in database
                                while($rows=mysqli_fetch_assoc($res))
                                {
                                    //Using While loop to get all the data from database.
                                    //And while loop will run as long as we have data in database

                                    //Get individual DAta
                                    $id=$rows['id'];
                                    $full_name=$rows['name'];
                                    $contact=$rows['contact'];
                                    $address=$rows['address'].' /  '.$rows['city'];
                                    $debitcard=$rows['debitcard'];
                                    $email=$rows['email'];

                                    //Display the Values in our Table
                                    ?>
                                    
                                    <tr>
                                        <td><?php echo $sn++; ?>. </td>
                                        <td><?php echo $full_name; ?></td>
                                        <td><?php echo $email; ?></td>
                                        <td><?php echo $contact; ?></td>
                                        <td><?php echo $address; ?></td>
                                        <td><?php echo $debitcard; ?></td>
                                        <td>
                                            <a href="<?php echo SITEURL; ?>admin/update-user.php?id=<?php echo $id; ?>" class="btn-secondary">Update User</a><br>
                                            <a href="<?php echo SITEURL; ?>admin/delete-user.php?id=<?php echo $id; ?>" class="btn-danger">Delete User</a>
                                        </td>
                                    </tr>

                                    <?php

                                }
                            }
                            else
                            {
                                //We Do not Have Data in Database
                            }
                        }

                    ?>


                    
                </table>

            </div>
        </div>
        <!-- Main Content Setion Ends -->

<?php include('partials/footer.php'); ?>