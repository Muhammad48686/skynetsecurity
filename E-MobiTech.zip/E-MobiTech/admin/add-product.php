<?php include('partials/menu.php'); ?>

<div class="main-content">
    <div class="wrapper">
        <h1>Add Product</h1>

        <br><br>
        <?php 
            if(isset($_SESSION['upload']))
            {
                echo $_SESSION['upload'];
                unset($_SESSION['upload']);
            }
        ?>

        <form action="" method="POST" enctype="multipart/form-data">
        
            <table class="tbl-30">
                <tr>
                    <td>Title: </td>
                    <td>
                        <input type="text" name="title" placeholder="Title of the Product">
                    </td>
                </tr>
                   <tr>
                    <td>Brand: </td>
                    <td>
                        <input type="text" name="brand" placeholder="Brand (Company)">
                    </td>
                </tr>

                <tr>
                    <td>Type: </td>
                    <td>
                        <input type="text" name="type" placeholder="type (mobile / accessory)">
                    </td>
                </tr>
             
                <tr>
                    <td>Description: </td>
                    <td>
                        <textarea name="description" cols="30" rows="5" placeholder="Description of the Product."></textarea>
                    </td>
                </tr>

                <tr>
                    <td>Price: </td>
                    <td>
                        <input type="number" name="price">
                    </td>
                </tr>

                <tr>
                    <td>Select Image: </td>
                    <td>
                        <input type="file" name="image"> 
                    </td>
                </tr>

                <tr>
                    <td>Discount: </td>
                    <td>
                        <input type="text" name="discount" placeholder="Discount (e.g 10%)">
                    </td>
                </tr>
                <tr>
                    <td>Rating: </td>
                    <td>
                        <input type="text" name="rating" placeholder="rating (e.g 4.3)">
                    </td>
                </tr>

                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="Add Product" class="btn-secondary">
                    </td>
                </tr>

            </table>

        </form>

        
        <?php 

            //CHeck whether the button is clicked or not
            if(isset($_POST['submit']))
            {
                //Add the Product in Database
                //echo "Clicked";
                
                //1. Get the DAta from Form
                $title = $_POST['title'];
                $description = $_POST['description'];
                $discount = $_POST['discount'];
                $price = $_POST['price'];
                $brand = $_POST['brand'];
                $rating = $_POST['rating'];
                $type = $_POST['type'];
                $dprice=($price*$discount)/100;
                $new_price=$price-$dprice;
                //2. Upload the Image if selected
                //Check whether the select image is clicked or not and upload the image only if the image is selected
                if(isset($_FILES['image']['name']))
                {
                    //Get the details of the selected image
                    $image_name = $_FILES['image']['name'];

                    //Check Whether the Image is Selected or not and upload image only if selected
                    if($image_name!="")
                    {
                        // Image is SElected
                       
                        //B. Upload the Image
                        //Get the Src Path and DEstinaton path

                        // Source path is the current location of the image
                        $src = $_FILES['image']['tmp_name'];

                        //Destination Path for the image to be uploaded
                        $dst = "../assets/img/$image_name";

                        //Finally Uppload the Product image
                        $upload = move_uploaded_file($src, $dst);

                        //check whether image uploaded or not
                        if($upload==false)
                        {
                            //Failed to Upload the image
                            //REdirect to Add Product Page with Error Message
                            $_SESSION['upload'] = "<div class='error'>Failed to Upload Image.</div>";
                            header('location:'.SITEURL.'admin/add-Product.php');
                            //STop the process
                            die();
                        }

                    }

                }
                else
                {
                    $image_name = ""; //SEtting DEfault Value as blank
                }

                //3. Insert Into Database

                //Create a SQL Query to Save or Add A Product
                // For Numerical we do not need to pass value inside quotes '' But for string value it is compulsory to add quotes ''
                $sql2 = "INSERT INTO items SET 
                    title = '$title',
                    description = '$description',
                    brand_name='$brand' ,
                    price = $price ,
                    image= '$image_name',
                    discount=$discount ,
                    new_price=$new_price,
                    rating=$rating ,
                    type='$type'
                ";

                //Execute the Query
                $res2 = mysqli_query($conn, $sql2);

                //CHeck whether data inserted or not
                //4. Redirect with MEssage to Manage Product page
                if($res2 == true)
                {
                    //Data inserted Successfullly
                    $_SESSION['add'] = "<div class='success'>Product Added Successfully.</div>";
                    header('location:'.SITEURL.'admin/manage-Product.php');
                }
                else
                {
                    //FAiled to Insert Data
                    $_SESSION['add'] = "<div class='error'>Failed to Add a Product.</div>";
                    header('location:'.SITEURL.'admin/manage-Product.php');
                }

                
            }

        ?>


    </div>
</div>

<?php include('partials/footer.php'); ?>