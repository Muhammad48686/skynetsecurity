-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 20, 2024 at 09:25 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e-mobitech`
--

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `brand_name` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(50) NOT NULL,
  `discount` int(11) NOT NULL,
  `new_price` int(11) NOT NULL,
  `rating` float NOT NULL,
  `description` varchar(3000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `brand_name`, `type`, `title`, `price`, `image`, `discount`, `new_price`, `rating`, `description`) VALUES
(2, 'apple', 'mobile', 'iphone 11', 129999, 'i11.jpg', 7, 120899, 4.2, 'This is an APPLE iPhone 11 with Specs:<br>\r\n\r\n6.1\"  FHD display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n256-GB Storage---<br>\r\n12-MP Camera--<br>\r\nHD Speaker---<br>\r\n3400maH Battery---<br>\r\n18W Fast Charging---<br>\r\n\r\n\r\n'),
(3, 'apple', 'mobile', 'iphone 11 pro', 169999, 'i11p.jpg', 9, 154699, 4.4, 'This is an APPLE iPhone 11 Pro with Specs:<br>\r\n\r\n5.9\"  FHD display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n256-GB Storage---<br>\r\n12-MP Camera--<br>\r\nHD Speaker---<br>\r\n3800maH Battery---<br>\r\n18W Fast Charging---<br>'),
(4, 'apple', 'mobile', 'iphone 11 pro max', 210999, 'i11pm.jpg', 9, 192009, 4.5, 'This is an APPLE iPhone 11 Pro Max with Specs:<br>\r\n\r\n6.5\"  FHD display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n256-GB Storage---<br>\r\n12-MP Camera--<br>\r\nHD Speaker---<br>\r\n4000maH Battery---<br>\r\n20W Fast Charging---<br>'),
(5, 'apple', 'mobile', 'iphone 12 mini', 145999, 'i12m.jpg', 6, 137239, 4.2, 'This is an APPLE iPhone 12 mini with Specs:<br>\r\n\r\n5.8\"  FHD display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n128-GB Storage---<br>\r\n12-MP Camera--<br>\r\nHD Speaker---<br>\r\n2900maH Battery---<br>\r\n20W Fast Charging---<br>'),
(6, 'apple', 'mobile', 'iphone 12', 172999, 'i12.jpg', 6, 162619, 4.3, 'This is an APPLE iPhone 12 with Specs:<br>\r\n\r\n6.1\"  FHD display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n256-GB Storage---<br>\r\n12-MP Camera--<br>\r\nHD Speaker---<br>\r\n3300maH Battery---<br>\r\n25W Fast Charging---<br>'),
(7, 'apple', 'mobile', 'iphone 12 pro', 224999, 'i12p.jpg', 9, 204749, 4.5, 'This is an APPLE iPhone 12 pro with Specs:<br>\r\n\r\n6.1\"  FHD display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n256-GB Storage---<br>\r\n12-MP Camera--<br>\r\nHD Speaker---<br>\r\n3400maH Battery---<br>\r\n25W Fast Charging---<br>'),
(8, 'apple', 'mobile', 'iphone 12 pro max', 259999, 'i12pm.jpg', 13, 226199, 4.7, 'This is an APPLE iPhone 12 pro max with Specs:<br>\r\n\r\n6.5\"  FHD display---<br>\r\nDual Sim 4G---<br>\r\n6-GB RAM---<br>\r\n256-GB Storage---<br>\r\n12-MP Camera--<br>\r\nHD Speaker---<br>\r\n4300maH Battery---<br>\r\n25W Fast Charging---<br>'),
(9, 'apple', 'mobile', 'iphone 13 mini', 183999, 'i13m.jpg', 6, 172959, 4.3, 'This is an APPLE iPhone 13 mini with Specs:<br>\r\n\r\n5.7\"  FHD display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n256-GB Storage---<br>\r\n12-MP Camera--<br>\r\nHD Speaker---<br>\r\n3100maH Battery---<br>\r\n25W Fast Charging---<br>'),
(10, 'apple', 'mobile', 'iphone 13 ', 210999, 'i13.jpg', 9, 192009, 4.6, 'This is an APPLE iPhone 13 with Specs:<br>\r\n\r\n6.1\"  FHD display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n256-GB Storage---<br>\r\n12-MP Camera--<br>\r\nHD Speaker---<br>\r\n4000maH Battery---<br>\r\n25W Fast Charging---<br>'),
(11, 'apple', 'mobile', 'iphone 13 pro', 265999, 'i13p.jpg', 8, 244719, 4.8, 'This is an APPLE iPhone 13 pro with Specs:<br>\r\n\r\n6.3\"  FHD display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n256-GB Storage---<br>\r\n12-MP Camera--<br>\r\nHD Speaker---<br>\r\n4300maH Battery---<br>\r\n25W Fast Charging---<br>'),
(12, 'apple', 'mobile', 'iphone 13 pro max', 286999, 'i13pm.jpg', 9, 261169, 4.9, 'This is an APPLE iPhone 13 pro max with Specs:<br>\r\n\r\n6.5\"  FHD display---<br>\r\nDual Sim 4G---<br>\r\n6-GB RAM---<br>\r\n512-GB Storage---<br>\r\n12-MP Camera--<br>\r\nHD Speaker---<br>\r\n4500maH Battery---<br>\r\n30W Fast Charging---<br>'),
(13, 'apple', 'mobile', 'iphone se 2022', 139999, 'se22.jpg', 5, 132999, 4.3, 'This is an APPLE iPhone SE 2022 with Specs:<br>\r\n\r\n4.7\"  FHD display---<br>\r\nDual Sim 4G---<br>\r\n3-GB RAM---<br>\r\n128-GB Storage---<br>\r\n12-MP Camera--<br>\r\nHD Speaker---<br>\r\n2400maH Battery---<br>\r\n15W Fast Charging---<br>'),
(14, 'samsung', 'mobile', 'samsung a03', 17500, 'a03.jpg', 6, 16450, 3.7, 'This is an Samsung Smartphone with Specs:<br>\r\n\r\n6.5\"  HD+ display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n64-GB Storage---<br>\r\n48-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n8W Fast Charging---<br>'),
(15, 'samsung', 'mobile', 'samsung a03s ', 20799, 'a03s.jpg', 7, 19343, 3.8, 'This is an Samsung Smartphone with Specs:<br>\r\n\r\n6.5\"  HD+ display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n64-GB Storage---<br>\r\n13-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n8W Fast Charging---<br>'),
(16, 'samsung', 'mobile', 'samsung a13 4/128', 30499, 'a13.jpg', 9, 27754, 4.1, 'This is an Samsung Smartphone with Specs:<br>\r\n\r\n6.5\"  HD+ display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n64-GB Storage---<br>\r\n50-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n15W Fast Charging---<br>'),
(17, 'samsung', 'mobile', 'samsung A22', 38999, 'a22.jpg', 8, 35879, 4.4, 'This is an Samsung Smartphone with Specs:<br>\r\n\r\n6.4\"  HD+ AMOLED display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n64-GB Storage---<br>\r\n50-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n15W Fast Charging---<br>'),
(18, 'samsung', 'mobile', 'samsung a32', 44299, 'a32.jpg', 7, 41198, 4.5, 'This is an Samsung Smartphone with Specs:<br>\r\n\r\n6.5\"  FHD+ AMOLED display---<br>\r\nDual Sim 4G---<br>\r\n6-GB RAM---<br>\r\n128-GB Storage---<br>\r\n64-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n15W Fast Charging---<br>'),
(19, 'samsung', 'mobile', 'samsung A23', 39999, 'a23.jpg', 6, 37599, 4.4, 'This is an Samsung Smartphone with Specs:<br>\r\n\r\n6.5\"  FHD+ display---<br>\r\nDual Sim 4G---<br>\r\n6-GB RAM---<br>\r\n128-GB Storage---<br>\r\n50-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n25W Fast Charging---<br>'),
(20, 'samsung', 'mobile', 'samsung a33 ', 68999, 'a33.jpg', 6, 64859, 4.6, 'This is an Samsung Smartphone with Specs:<br>\r\n\r\n6.5\"  FHD+ AMOLED display---<br>\r\nDual Sim 5G---<br>\r\n8-GB RAM---<br>\r\n128-GB Storage---<br>\r\n50-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n25W Fast Charging---<br>'),
(21, 'samsung', 'mobile', 'samsung a52', 57499, 'a52.jpg', 10, 51749, 4.6, 'This is an Samsung Smartphone with Specs:<br>\r\n\r\n6.5\"  FHD+ AMOLED display---<br>\r\nDual Sim 4G---<br>\r\n8-GB RAM---<br>\r\n128-GB Storage---<br>\r\n48-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n25W Fast Charging---<br>'),
(22, 'samsung', 'mobile', 'samsung a52s', 65999, 'a52s.jpg', 10, 59399, 4.6, 'This is an Samsung Smartphone with Specs:<br>\r\n\r\n6.5\"  FHD+ AMOLED display---<br>\r\nDual Sim 5G---<br>\r\n8-GB RAM---<br>\r\n128-GB Storage---<br>\r\n50-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n25W Fast Charging---<br>'),
(23, 'samsung', 'mobile', 'samsung a72', 75499, 'a72.jpg', 18, 61909, 4.7, 'This is an Samsung Smartphone with Specs:<br>\r\n\r\n6.5\"  FHD+ AMOLED display---<br>\r\nDual Sim 4G---<br>\r\n8-GB RAM---<br>\r\n128-GB Storage---<br>\r\n64-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n25W Fast Charging---<br>'),
(24, 'samsung', 'mobile', 'samsung s21 fe', 126999, 's21fe.jpg', 11, 113029, 4.7, 'This is an Samsung Smartphone with Specs:<br>\r\n\r\n6.5\"  FHD+ AMOLED display---<br>\r\nDual Sim 5G---<br>\r\n8-GB RAM---<br>\r\n128-GB Storage---<br>\r\n12-MP Camera--<br>\r\nHD Speaker---<br>\r\n4500maH Battery---<br>\r\n25W Fast Charging---<br>'),
(25, 'samsung', 'mobile', 'samsung s22', 168999, 's22.jpg', 10, 152099, 4.8, 'This is an Samsung Smartphone with Specs:<br>\r\n\r\n6.1\"  FHD+ AMOLED display---<br>\r\nDual Sim 5G---<br>\r\n8-GB RAM---<br>\r\n128-GB Storage---<br>\r\n12-MP Camera--<br>\r\nHD Speaker---<br>\r\n4200maH Battery---<br>\r\n25W Fast Charging---<br>'),
(26, 'samsung', 'mobile', 'samsung s22+', 197999, 's22p.jpg', 12, 174239, 4.8, 'This is an Samsung Smartphone with Specs:<br>\r\n\r\n6.5\"  FHD+ AMOLED display---<br>\r\nDual Sim 5G---<br>\r\n8-GB RAM---<br>\r\n128-GB Storage---<br>\r\n12-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n25W Fast Charging---<br>'),
(27, 'samsung', 'mobile', 'samsung s22 ultra', 225999, 's22u.jpg', 12, 198879, 4.9, 'This is an Samsung Smartphone with Specs:<br>\r\n\r\n6.8\"  FHD+ AMOLED display---<br>\r\nDual Sim 5G---<br>\r\n8-GB RAM---<br>\r\n256-GB Storage---<br>\r\n108-MP Camera--<br>\r\nHD Speaker---<br>\r\n4900maH Battery---<br>\r\n25W Fast Charging---<br>'),
(28, 'samsung', 'mobile', 'Samsung z fold 3', 301999, 'zf3.jpg', 10, 271799, 4.7, 'This is an Samsung Smartphone with Specs:<br>\r\n\r\n7.6\"  FHD+ AMOLED display---<br>\r\nDual Sim 5G---<br>\r\n12-GB RAM---<br>\r\n256-GB Storage---<br>\r\n12-MP Camera--<br>\r\nHD Speaker---<br>\r\n4400maH Battery---<br>\r\n25W Fast Charging---<br>'),
(29, 'vivo', 'mobile', 'vivo y01', 18199, 'y01.jpg', 6, 17107, 3.5, 'This is a VIVO Smartphone with Specs:<br>\r\n\r\n6.5\"  HD+  display---<br>\r\nDual Sim 4G---<br>\r\n2-GB RAM---<br>\r\n32-GB Storage---<br>\r\n13-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n10W Fast Charging---<br>'),
(30, 'vivo', 'mobile', 'vivo y15s', 23999, 'y15s.jpg', 7, 22319, 3.7, 'This is a VIVO Smartphone with Specs:<br>\r\n\r\n6.5\"  HD+  display---<br>\r\nDual Sim 4G---<br>\r\n3-GB RAM---<br>\r\n32-GB Storage---<br>\r\n13-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n10W Fast Charging---<br>'),
(31, 'vivo', 'mobile', 'vivo y21', 30999, 'y21.jpg', 12, 27279, 4, 'This is a VIVO Smartphone with Specs:<br>\r\n\r\n6.5\"  HD+  display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n64-GB Storage---<br>\r\n13-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n18W Fast Charging---<br>'),
(32, 'vivo', 'mobile', 'vivo y21t', 37999, 'y21t.jpg', 8, 34959, 4.3, 'This is a VIVO Smartphone with Specs:<br>\r\n\r\n6.5\"  HD+  display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n128-GB Storage---<br>\r\n50-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n18W Fast Charging---<br>'),
(33, 'vivo', 'mobile', 'vivo y33t', 43999, 'y33t.jpg', 9, 40039, 4.4, 'This is a VIVO Smartphone with Specs:<br>\r\n\r\n6.5\"  HD+  display---<br>\r\nDual Sim 4G---<br>\r\n8-GB RAM---<br>\r\n128-GB Storage---<br>\r\n50-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n18W Fast Charging---<br>'),
(34, 'vivo', 'mobile', 'vivo v23e', 54999, 'v23e.jpg', 10, 49499, 4.7, 'This is a VIVO Smartphone with Specs:<br>\r\n\r\n6.5\"  FHD+ AMOLED  display---<br>\r\nDual Sim 4G---<br>\r\n8-GB RAM---<br>\r\n128-GB Storage---<br>\r\n64-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n40W Fast Charging---<br>'),
(35, 'vivo', 'mobile', 'vivo v23 5g', 91999, 'v23.jpg', 10, 82799, 4.8, 'This is a VIVO Smartphone with Specs:<br>\r\n\r\n6.5\"  FHD+ AMOLED  display---<br>\r\nDual Sim 5G---<br>\r\n8-GB RAM---<br>\r\n128-GB Storage---<br>\r\n64-MP Camera--<br>\r\nHD Speaker---<br>\r\n4500maH Battery---<br>\r\n60W Fast Charging---<br>'),
(36, 'vivo', 'mobile', 'vivo x80', 159999, 'x80.jpg', 7, 148799, 4.9, 'This is a VIVO Smartphone with Specs:<br>\r\n\r\n6.5\"  FHD+ AMOLED  display---<br>\r\nDual Sim 4G---<br>\r\n12-GB RAM---<br>\r\n256-GB Storage---<br>\r\n108-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n60W Fast Charging---<br>'),
(130, 'nokia', 'mobile', 'nokia g11', 29999, 'nokia-g11.jpg', 8, 27599, 4, 'This is a NOKIA Smartphone with Specs:<br>\r\n\r\n6.5\"  HD+  display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n128-GB Storage---<br>\r\n50-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n18W Fast Charging---<br>'),
(133, 'Gionee', 'accessory', 'Gionee Handfree 3.5mm', 399, 'gionee-handfree.jpg', 5, 379, 4.8, 'Crystal clear sound and best quality handfree for smartphone users who like music or make long calls.'),
(134, 'anker', 'accessory', 'Anker 65W Charger', 5599, '65w-2_165x.webp', 12, 4927, 4.8, 'This is a fast charger to enable your device to charge in a few minutes if its supported the 65w charging option.'),
(135, 'apple', 'accessory', 'Apple 20W fast Charger', 3499, '20w.jpg', 7, 3254, 4.5, 'This is a  fast charger for iPhone  to charge in  1hr+30minutes if its supported the 20w fast charging option.'),
(136, 'xiaomi', 'accessory', 'Xiaomi Fast Charger', 2899, '33w.jpg', 5, 2754, 4.4, 'This is a fast charger to enable your device to charge in a few minutes if its supported the 33w charging option.'),
(137, 'anker', 'accessory', 'Anker 45W Fast Charger', 4199, '45w_165x.webp', 8, 3863, 4.6, 'This is a fast charger to enable your device to charge in a few minutes if its supported the 45w charging option.'),
(138, 'oppo', 'mobile', 'oppo a16', 29999, 'oppo-a16.jpg', 8, 27599, 4.1, 'This is an OPPO Smartphone with Specs:<br>\r\n\r\n6.5\"  HD+  display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n64-GB Storage---<br>\r\n13-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n10W Fast Charging---<br>'),
(139, 'oppo', 'mobile', 'oppo a54', 34999, 'oppo-a54.jpg', 8, 32199, 4.3, 'This is an OPPO Smartphone with Specs:<br>\r\n\r\n6.5\"  HD+  display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n128-GB Storage---<br>\r\n13-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n18W Fast Charging---<br>'),
(141, 'oppo', 'mobile', 'Oppo A16k', 23999, 'oppo-a16k.jpg', 7, 22319, 4.1, 'This is an OPPO Smartphone with Specs:<br>\r\n\r\n6.5\"  HD+  display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n64-GB Storage---<br>\r\n13-MP Camera--<br>\r\nHD Speaker---<br>\r\n4250maH Battery---<br>\r\n10W Fast Charging---<br>'),
(142, 'oppo', 'mobile', 'OPPO A16e', 21999, 'oppo-a16k (1).jpg', 6, 20679, 4.1, 'This is an OPPO Smartphone with Specs:<br>\r\n\r\n6.5\"  HD+  display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n64-GB Storage---<br>\r\n13-MP Camera--<br>\r\nHD Speaker---<br>\r\n4250maH Battery---<br>\r\n10W Fast Charging---<br>'),
(143, 'oppo', 'mobile', 'oppo a76', 37999, 'oppo-a36 (1).jpg', 7, 35339, 4.4, 'This is an OPPO Smartphone with Specs:<br>\r\n\r\n6.5\"  HD+  display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n128-GB Storage---<br>\r\n13-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n18W Fast Charging---<br>'),
(144, 'oppo', 'mobile', 'oppo a96', 47999, 'oppo-a96-new.jpg', 8, 44159, 4.5, 'This is an OPPO Smartphone with Specs:<br>\r\n\r\n6.5\"  HD+  display---<br>\r\nDual Sim 4G---<br>\r\n8-GB RAM---<br>\r\n128-GB Storage---<br>\r\n50-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n33W Fast Charging---<br>'),
(145, 'oppo', 'mobile', 'oppo f21 pro', 55999, 'oppo-reno7-4g.jpg', 10, 50399, 4.7, 'This is an OPPO Smartphone with Specs:<br>\r\n\r\n6.4\"  FHD+ AMOLED display---<br>\r\nDual Sim 4G---<br>\r\n8-GB RAM---<br>\r\n128-GB Storage---<br>\r\n64-MP Camera--<br>\r\nHD Speaker---<br>\r\n4500maH Battery---<br>\r\n33W Fast Charging---<br>'),
(146, 'oppo', 'mobile', 'OPPO F21 PRO 5G', 69999, 'oppo-reno7-z-5g.jpg', 8, 64399, 4.8, 'This is an OPPO Smartphone with Specs:<br>\r\n\r\n6.4\"  FHD+ AMOLED display---<br>\r\nDual Sim 5G---<br>\r\n8-GB RAM---<br>\r\n128-GB Storage---<br>\r\n64-MP Camera--<br>\r\nHD Speaker---<br>\r\n4500maH Battery---<br>\r\n33W Fast Charging---<br>'),
(147, 'xiaomi', 'mobile', 'REDMI NOTE 11', 39999, 'xiaomi-redmi-note-11-global.jpg', 8, 36799, 4.6, 'This is a Xiaomi Smartphone with Specs:<br>\r\n\r\n6.4\"  FHD+ AMOLED display---<br>\r\nDual Sim 4G---<br>\r\n6-GB RAM---<br>\r\n128-GB Storage---<br>\r\n50-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n33W Fast Charging---<br>'),
(148, 'xiaomi', 'mobile', 'redmi note 11 pro', 54999, 'xiaomi-redmi-note-11-pro-global.jpg', 6, 51699, 4.7, 'This is a Xiaomi Smartphone with Specs:<br>\r\n\r\n6.4\"  FHD+ AMOLED display---<br>\r\nDual Sim 4G---<br>\r\n8-GB RAM---<br>\r\n128-GB Storage---<br>\r\n64-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n33W Fast Charging---<br>'),
(149, 'xiaomi', 'mobile', 'redmi 10A', 22999, 'xiaomi-redmi-10a.jpg', 7, 21389, 4.1, 'This is a Xiaomi Smartphone with Specs:<br>\r\n\r\n6.7\"  HD+ display---<br>\r\nDual Sim 4G---<br>\r\n3-GB RAM---<br>\r\n64-GB Storage---<br>\r\n13-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n10W Fast Charging---<br>'),
(150, 'xiaomi', 'mobile', 'REDMI 10C', 32999, 'xiaomi-redmi-10c.jpg', 7, 30689, 4.2, 'This is a Xiaomi Smartphone with Specs:<br>\r\n\r\n6.7\"  HD+ display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n128-GB Storage---<br>\r\n13-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n18W Fast Charging---<br>'),
(151, 'nokia', 'mobile', 'NOKIA G21', 31999, 'nokia-g21-dusk.jpg', 6, 30079, 4.4, 'This is a NOKIA Smartphone with Specs:<br>\r\n\r\n6.5\"  FHD+  display---<br>\r\nDual Sim 4G---<br>\r\n6-GB RAM---<br>\r\n128-GB Storage---<br>\r\n50-MP Camera--<br>\r\nHD Speaker---<br>\r\n5050maH Battery---<br>\r\n18W Fast Charging---<br>'),
(152, 'nokia', 'mobile', 'NOKIA G20', 26999, 'nokia-g20.jpg', 8, 24839, 4.3, 'This is a NOKIA Smartphone with Specs:<br>\r\n\r\n6.5\"  HD+  display---<br>\r\nDual Sim 4G---<br>\r\n4-GB RAM---<br>\r\n128-GB Storage---<br>\r\n50-MP Camera--<br>\r\nHD Speaker---<br>\r\n5000maH Battery---<br>\r\n10W Fast Charging---<br>'),
(153, 'nokia', 'mobile', 'nokia 225 4g', 5899, 'nokia-225-4g.jpg', 5, 5604, 4.1, 'This is a NOKIA Feature phone with Specs:<br>\r\n\r\n2.4\"   display---<br>\r\nDual Sim 4G---<br>\r\n2-MP Camera--<br>\r\nHD Speaker---<br>\r\n1150maH Battery---<br>\r\n'),
(154, 'nokia', 'mobile', 'nokia 6300 4g', 9499, 'nokia-6300-4g.jpg', 7, 8834, 4.4, 'This is a NOKIA Feature phone with Specs:<br>\r\n\r\n2.4\"   display---<br>\r\nWIFI+Hotspot---<br>\r\nDual Sim 4G---<br>\r\n0.3-MP Camera--<br>\r\nHD Speaker---<br>\r\n1500maH Battery---<br>'),
(155, 'nokia', 'mobile', 'nokia 110 4g', 4699, 'nokia-110-4g.jpg', 5, 4464, 4.1, 'This is a NOKIA Feature phone with Specs:<br>\r\n\r\n1.8\"   display---<br>\r\nDual Sim 4G---<br>\r\n0.3-MP Camera--<br>\r\nHD Speaker---<br>\r\n1150maH Battery---<br>'),
(156, 'nokia', 'mobile', 'nokia 110', 3999, 'nokia-110-2019.jpg', 4, 3839, 3.8, 'This is a NOKIA Feature phone with Specs:<br>\r\n\r\n1.8\"   display---<br>\r\nDual Sim---<br>\r\n0.3-MP Camera--<br>\r\nHD Speaker---<br>\r\n1020maH Battery---<br>'),
(157, 'nokia', 'mobile', 'nokia 105', 2999, 'nokia-105-2019.jpg', 3, 2909, 3.7, 'This is a NOKIA Feature phone with Specs:<br>\r\n\r\n1.8\"   display---<br>\r\nDual Sim---<br>\r\nHD Speaker---<br>\r\n800maH Battery---<br>');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `item_price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` int(11) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `item_id`, `item_name`, `item_price`, `quantity`, `total_price`, `order_date`, `status`) VALUES
(154, 1, 15, 'samsung a03s ', 20799, 1, 20799, '2022-06-10 02:03:21', 'Delivered'),
(155, 1, 30, 'vivo y15s', 21499, 1, 21499, '2022-06-10 09:06:22', 'Delivered'),
(176, 1, 34, 'vivo v23e', 49999, 1, 49999, '2022-06-11 11:05:54', 'Delivered'),
(214, 1, 7, 'iphone 12 pro', 204749, 1, 204749, '2022-06-13 03:20:35', 'Delivered'),
(215, 1, 136, 'Xiaomi Fast Charger', 2754, 1, 2754, '2022-06-13 10:36:15', 'Delivered'),
(216, 1, 27, 'samsung s22 ultra', 198879, 1, 198879, '2022-06-14 02:21:28', 'Delivered'),
(217, 1, 135, 'Apple 20W fast Charger', 3254, 1, 3254, '2022-06-14 02:21:28', 'Delivered'),
(243, 1, 133, 'Gionee Handfree 3.5mm', 379, 1, 379, '2022-06-22 07:40:28', 'Delivered'),
(244, 1, 136, 'Xiaomi Fast Charger', 2754, 1, 2754, '2022-06-22 07:43:46', 'Cancelled'),
(245, 1, 7, 'iphone 12 pro', 204749, 1, 204749, '2022-06-22 07:47:01', 'Delivered'),
(246, 1, 135, 'Apple 20W fast Charger', 3254, 2, 6508, '2022-06-26 12:32:27', 'Delivered'),
(252, 1, 24, 'samsung s21 fe', 113029, 1, 113029, '2022-06-26 01:07:09', 'Delivered'),
(256, 1, 10, 'iphone 13 ', 192009, 1, 192009, '2022-06-26 01:31:09', 'Delivered'),
(259, 1, 130, 'nokia g11', 27599, 1, 27599, '2022-07-09 10:57:01', 'Delivered'),
(260, 1, 35, 'vivo v23 5g', 82799, 1, 82799, '2022-07-09 11:01:10', 'On Delivery'),
(261, 1, 21, 'samsung a52', 51749, 1, 51749, '2022-07-09 11:07:16', 'On Delivery'),
(262, 9, 35, 'vivo v23 5g', 82799, 1, 82799, '2022-07-09 11:31:26', 'On Delivery'),
(263, 9, 26, 'samsung s22+', 174239, 1, 174239, '2022-07-09 11:47:32', 'On Delivery'),
(265, 9, 28, 'Samsung z fold 3', 271799, 1, 271799, '0000-00-00 00:00:00', 'Added to cart'),
(266, 1, 24, 'samsung s21 fe', 113029, 1, 113029, '2022-07-15 11:02:59', 'Pending'),
(267, 1, 8, 'iphone 12 pro max', 226199, 1, 226199, '2022-07-15 04:09:44', 'Pending'),
(268, 1, 35, 'vivo v23 5g', 82799, 2, 165598, '2022-07-15 04:09:44', 'Delivered'),
(269, 1, 12, 'iphone 13 pro max', 261169, 1, 261169, '0000-00-00 00:00:00', 'Added to cart'),
(270, 10, 28, 'Samsung z fold 3', 271799, 2, 543598, '2024-05-13 10:50:08', 'On Delivery'),
(271, 10, 12, 'iphone 13 pro max', 261169, 1, 261169, '2024-05-15 12:15:22', 'Pending'),
(272, 10, 11, 'iphone 13 pro', 244719, 1, 244719, '2024-05-15 12:16:02', 'Pending'),
(273, 10, 8, 'iphone 12 pro max', 226199, 1, 226199, '2024-05-15 12:16:02', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `full_name`, `username`, `password`) VALUES
(0, 'Mudasir', 'admin2', '6dd9fcad0bbc42b855530c44a890729f'),
(12, 'Syed Mubashir ', 'admin', '6325ae85d932504df0319223a2d5e7e7');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `debitcard` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `contact`, `city`, `address`, `debitcard`) VALUES
(1, 'Syed Mubashir', 'syed.mub44@gmail.com', '14e1b600b1fd579f47433b88e8d85291', '03136033913', 'Multan', 'Vehari Chowk Near Cricket  stadium', '1234567812345678'),
(9, 'Bilal Sahil', 'sahil@gmail.com', '0f8fad117740dc78cb2e834068b94fab', '03084896709', 'Multan', 'Sujan Pur', '1234123456785678'),
(10, 'mudasir', 'mudasir123@gmail.com', '69d9d33fe2c31798bf38980f01a82cb1', '03492953254', 'Multan', 'Vehari Road', '1111222233334444');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`,`item_id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`,`username`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=274;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
