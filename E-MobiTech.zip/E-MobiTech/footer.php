<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!--========== BOX ICONS ==========-->
        <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>

        <!--========== CSS ==========-->
        <link rel="stylesheet" href="assets/css/styles.css">

    </head>
    <body>
        <!--========== SCROLL TOP ==========-->
        <a href="#" class="scrolltop" id="scroll-top">
            <i class='bx bx-up-arrow-alt scrolltop__icon'></i>
        </a>
<!--========== FOOTER ==========-->
                 <footer class="footer section">
            <div class="footer__container bd-container bd-grid">
              
                <div class="footer__content">
                    <h3 class="footer__title">Our Services</h3>
                    <ul>
                        <li><a href="index.php#share" class="footer__link"><h5>Discounts</h5></a></li>
                        <li><a href="shipping.php" class="footer__link"><h5>Shipping mode</h5></a></li>
                    </ul>
                </div>

                <div class="footer__content">
                    <h3 class="footer__title">Our Company</h3>
                    <ul>
                        <li><a href="aboutus.php" class="footer__link"><h5>About us</h5></a></li>
                        <li><a href="aboutus.php" class="footer__link"><h5>Our mision</h5></a></li>
                    </ul>
                </div>

                <div class="footer__content">
                    <h3 class="footer__title">Contact Us</h3>
                    <a href="https://www.facebook.com/e_mobitech" class="footer__social"><i class='bx bxl-facebook-circle '></i></a>
                    <a href="https://www.instagram.com/e_mobitech" class="footer__social"><i class='bx bxl-instagram-alt'></i></a>
                    <a  class="footer__social"><i class='bx bxl-whatsapp'></i>+923492953254</a>
                </div>
            </div>
            <br><br>
            <center><h5> &copy <?php echo date("Y"); ?> E-MOBITECH. All Rights Reserved. Developed by : Syed M. Mudasir Ahmed</h5></center>
        </footer>
        <!--========== SCROLL REVEAL ==========-->
        <script src="https://unpkg.com/scrollreveal"></script>
                   <!--========== MAIN JS ==========-->
                   <script src="assets/js/main.js"></script>

    </body>
</html>