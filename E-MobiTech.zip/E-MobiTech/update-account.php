<?php 
require('connection.php');
 //1. Get the ID of Selected User
 $id=$_GET['id'];
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Mobile Space | Update/User Account</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="assets/css/admin.css">

    </head>
<body>
<div class="main-content">
<div class="container">
        <a href="index.php" class="btn-primary">Back to Homepage</a>
    </div>
    <div class="wrapper">
        <h1>Update Your Account Details</h1>

        <br><br>

        <?php 

            //2. Create SQL Query to Get the Details
            $sql="SELECT * FROM Users WHERE id=$id";

            //Execute the Query
            $res=mysqli_query($con, $sql);

            //Check whether the query is executed or not
            if($res==true)
            {
                // Check whether the data is available or not
                $count = mysqli_num_rows($res);
                //Check whether we have User data or not
                if($count==1)
                {
                    // Get the Details
                    //echo "User Available";
                    $row=mysqli_fetch_assoc($res);

                    $full_name = $row['name'];
                    $email = $row['email'];
                    $contact = $row['contact'];
                    $debitcard = $row['debitcard'];
                    $address = $row['address'];
                    $city = $row['city'];

                }
                else
                {
                    //Redirect  home
                    header('location: index.php');
                }
            }
        
        ?>


        <form action="" method="POST">

            <table class="tbl-30">
                <tr>
                    <td>Full Name: </td>
                    <td>
                        <input type="text" name="full_name" value="<?php echo $full_name; ?>">
                    </td>
                </tr>

                <tr>
                    <td>Contact: (11-digit) </td>
                    <td>
                        <input type="tel" name="contact" value="<?php echo $contact; ?>">
                    </td>
                </tr>   <tr>
                    <td>Address: </td>
                    <td>
                        <input type="textarea" name="address" value="<?php echo $address; ?>">
                    </td>
                </tr>
                <tr>
                    <td>City: </td>
                    <td>
                        <input type="text" name="city" value="<?php echo $city; ?>">
                    </td>
                </tr>
                <tr>
                    <td>Debitcard#: (16-Digit) </td>
                    <td>
                        <input type="tel" name="debitcard" value="<?php echo $debitcard; ?>">
                    </td>
                </tr>
                

                <tr>
                    <td colspan="2">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <input type="submit" name="submit" value="Update user" class="btn-secondary">
                    </td>
                </tr>

            </table>

        </form>
    </div>
</div>

<?php 

    //Check whether the Submit Button is Clicked or not
    if(isset($_POST['submit']))
    {
        //echo "Button CLicked";
        //Get all the values from form to update
        $id = $_POST['id'];
        $full_name = $_POST['full_name'];
        $contact = $_POST['contact'];
        $address = $_POST['address'];
        $city = $_POST['city'];
        $debitcard = $_POST['debitcard'];

        //Create a SQL Query to Update user
        $sql = "UPDATE users SET
        name = '$full_name',
        contact = '$contact',
        address = '$address',
        city = '$city',
        debitcard = '$debitcard'
        WHERE id='$id'
        ";

        //Execute the Query
        $res = mysqli_query($con, $sql);

        //Check whether the query executed successfully or not
        if($res==true)
        {
            echo "Account updated successfully---";
            ?>
            <meta http-equiv="refresh" content="3;url=index.php" />
            <?php
        }
        else
        {
            //Failed to Update user
            ?>
            <script>
            window.alert("Failed to update data try again!");
            </script>
            <meta http-equiv="refresh" content="1;url=update-account.php" />
            <?php
        }
    }

?>
</body>
</html>