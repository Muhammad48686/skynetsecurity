<?php 
	require 'connection.php';
  session_start();
  if(!isset($_SESSION['email'])){
    header('location:login.php');
}else{
    $user_id=$_SESSION['id']; 
    $user_products_query="SELECT * FROM `orders` WHERE user_id='$user_id' AND status='Added to cart' order by order_id ASC ";
   $user_products_result=mysqli_query($con,$user_products_query) or die(mysqli_error($con));
   $no_of_user_products= mysqli_num_rows($user_products_result);
   $sum=0;
  }
 ?>
 <!DOCTYPE html>
  <html>
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="assets/css/styles.css">
      <title>Mobile Space | Checkout Order</title>
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
</head>
    </body>
    </head>
    <body>
            <div>
            <?php 
               require 'header.php';
            ?>
            </div>
    <br><br>
    <div class="container">
  <h4 style="text-decoration: bold">5-Steps to Place an Order---</h4>
  <div class="progress">
  <div class="progress-bar bg-primary" style="width:20%">1- login/sign up </div>
  <div class="progress-bar bg-danger" style="width:20%">2-Add to Cart</div>
  <div class="progress-bar bg-dark" style="width:20%">3- Confirm Cart</div>
  <div class="progress-bar bg-info" style="width:30%">4- Checkout</div>
  </div>
  <div>
    <h5>To Change User Details--- Update the Account and then Confirm Cart again.</h5>
    <a href="update-account.php?id=<?php echo $user_id; ?>" class="btn btn-primary">Update Account</a>
  </div>
      <!-- container-fluid starts -->
        <div class="container-fluid">
        <div class="row">
           <div class="col-md-6 col-sm-6 col-xs-6">
            <?php 
            	$user_query=mysqli_query($con,"SELECT * FROM `users` WHERE id='$user_id' ");
            	$user_data=mysqli_fetch_array($user_query);

             ?>
            <div id="printTable">
            <img src="assets/img/wlogo.png" width="100" height="75"style=" align:middle " >
            	<div>
             		<h3 style="text-decoration: underline; width: 300px;padding: 10px;padding-left: 15px;border-radius: 5px;"> User Information </h3>
             		<span style="font-size: 20px;"><b>Customer's Name :</b>   <?php echo $user_data['name']; ?></span><br>
             		<span style="font-size: 20px;"><b>Contact No.# :</b>      <?php echo $user_data['contact']; ?></span><br>
             		<span style="font-size: 20px;"><b>Delivery Address :</b>  <?php echo $user_data['address']; ?></span> <br>
                <span style="font-size: 20px;"><b>City :</b> <?php echo $user_data['city']; ?></span><br>
             </div>
             <h3 style="text-decoration: underline; width: 300px; padding: 10px;padding-left: 25px; border-radius: 5px;">Payment Details</h3>
             <h6><b> Payment Method :</b> Cash On Delivery</h6>
             <!-- Table starts -->
              <div class="container"><br>
              	<table class="table table-bordered">
                    <thead class="thead-light">
                        <tr>
                            <th>No.#</th><th>Product title</th><th>Price</th><th>Qty</th><th>Total</th>
                        </tr>
                    </thead>
                       <?php
                          if($no_of_user_products==0){
                            echo "Add items to cart first and confirm the order to get invoice bill.";
                           ?>
                               <script>
                               window.alert("No items in the Order!!");
                               </script>
                           <?php
                           }else{
                               while($row=mysqli_fetch_array($user_products_result)){
                                   $sum=$sum+$row['total_price']; 
                              }
                           }
                        $user_products_result=mysqli_query($con,$user_products_query) or die(mysqli_error($con));
                        $no_of_user_products= mysqli_num_rows($user_products_result);
                        $counter=1;
                       while($row=mysqli_fetch_array($user_products_result)){
                         ?>
                        <tr>
                            <th><?php echo $counter?></th><th><?php echo $row['item_name']?></th><th><?php echo $row['item_price']?></th>
                            <th><?php echo $row['quantity']?></th><th><?php echo $row['total_price']?></th>
                        </tr>
                       <?php $counter=$counter+1;
                      }?>
              	</table>
              	<br><br>
              <div align="center">
              	<span style="font-size: 20px;"><b>Grand Total: Rs </b><?php echo $sum; ?> /-</span><br><br>
                <button onclick="printData()" class="btn btn-outline-info">Print or Save as PDF</button>
                </div>
            </div>
            <!-- container Ends -->
            <br>
        </div>
        </div>
        <!-- Row Ends -->
         </div>
         <!-- Container-fluid Ends -->
         <div align="right">
          <a href="success-order.php" class="btn btn-success">Checkout to Place Order</a>
          </div>
        <?php include("footer.php") ; ?>
         <script type="text/javascript">
         	function printData(){
  							 var divToPrint=document.getElementById("printTable");
  								 newWin= window.open("");
   								newWin.document.write(divToPrint.outerHTML);
  								 newWin.print();
  								 newWin.close();
								}
         </script>
    </body>
  </html>
