<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
</head>
<body>
<?php
            require 'header.php';
           ?>
           <br>
           <br>
           <center><img src="assets/img/wlogo.png" style=" vertical-align:middle " ></center>
           <br><br>
           <div class="container-fluid bd-container" align="justify">
    <h1>Buying Made Simple. Everyday.</h1>
<h4>Compare prices, order and buy mobile phones and accessories online for hassle-free delivery to your home.</h4><br><br>
<h1>Our Mission</h1>
<h4>Our mission is to make it easy to do MOBILE Shopping anywhere via online.
We do this by helping buyers to find products quickly and efficiently.</h4>
</div>
     <!--========== MAIN JS ==========-->
     <script src="assets/js/main.js"></script>
</body>
</html>